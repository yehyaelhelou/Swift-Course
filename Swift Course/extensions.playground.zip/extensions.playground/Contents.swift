import UIKit

class MyClass {
    // Functionality
}

extension String {
    func reverse() -> String {
        var characterArray = [Character]()
        for character in self {
            characterArray.insert(character, at: 0)
        }
        return String(characterArray)
    }
}

var name = "yehya ahmed elhelou"
name.reverse()






extension Int {
    func squar() -> Int{
        return self * self
    }
}

var value = 9
value.squar()



extension Double {
   mutating func calculateArea(){
        let pi = 3.1415
        self = pi * (self * self)
    }
}

class Circle{
    var radius : Double
        init(radius:Double){
            self.radius = radius
        }
}

var circle = Circle(radius:3.3)
print(circle.radius)
//circle.radius.calculateArea()
